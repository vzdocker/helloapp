﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
//using MongoDB.Driver;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.OptionsModel;


namespace dockerPOC.Controllers
{
    public class HomeController : Controller
    {

        private readonly string dbUrl;
        private readonly string env;

        public HomeController(IOptions<DBSection> dbSetting)
        {
            dbUrl = dbSetting.Value.DB;
            env = dbSetting.Value.Env;
        }


        public IActionResult Index()
        {
            Console.Write("qw");

            var dd = Request.Host.Value;
            var ll = dd.Split(':');


            ViewData["env"] = env;
            ViewData["dbIP"] = dbUrl;
            //ViewData["Port"] = ll[1];
            //ViewData["IpAddr"] = AppSettings
            return View();
        }

        public IActionResult About()
        {

            //var mongoClient = new MongoClient();
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
